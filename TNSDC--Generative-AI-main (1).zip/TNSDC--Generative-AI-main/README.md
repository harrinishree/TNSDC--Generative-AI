# TNSDC--Generative-AI
https://replit.com/@harrinishreekr/DiscordChatGpt#TNSDC--Generative-AI/main.py 
https://replit.com/@harrinishreekr/DiscordChatGpt#TNSDC--Generative-AI/chat.txt
Use discord to make this code work.
The secret keys and the Open api keys are with me.
This code runs efficiently by using "Replit"
